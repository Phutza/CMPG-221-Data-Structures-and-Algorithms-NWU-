
/**
 * Write a description of class qw here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
class UndergraduateCourse extends Course 
{
    private boolean hasJava;

    // Constructor
    public UndergraduateCourse(String courseName, int courseDuration, boolean hasJava) 
    {
        super(courseName, courseDuration);
        this.hasJava = hasJava;
    }

    // Accessor
    public boolean getHasJava() 
    {
        return hasJava;
    }

    // Mutator
    public void setHasJava(boolean hasJava) 
    {
        this.hasJava = hasJava;
    }

    // Implementing the abstract method
    @Override
    public void displayCourseDetails() 
    {
        System.out.println("Undergraduate Course Details");
        System.out.println("Course Name: " + courseName);
        System.out.println("Duration: " + courseDuration + " years");
        System.out.println("Includes Java: " + (hasJava ? "Yes" : "No"));
    }

    // toString method
    @Override
    public String toString() 
    {
        return super.toString() + ", Includes Java: " + hasJava;
    }
}


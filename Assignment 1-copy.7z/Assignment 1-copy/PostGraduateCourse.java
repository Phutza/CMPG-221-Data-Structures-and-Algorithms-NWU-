

/**
 * Write a description of class sc here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
class PostGraduateCourse extends Course 
{
    private String researchTopic;

    // Constructor
    public PostGraduateCourse(String courseName, int courseDuration, String researchTopic) 
    {
        super(courseName, courseDuration);
        this.researchTopic = researchTopic;
    }

    // Accessor
    public String getResearchTopic() 
    {
        return researchTopic;
    }

    // Mutator
    public void setResearchTopic(String researchTopic) 
    {
        this.researchTopic = researchTopic;
    }

    // Implementing of the abstract method
     @Override
    public void displayCourseDetails() 
    {
        System.out.println("Post graduate Course Details");
        System.out.println("Course Name: " + courseName);
        System.out.println("Duration: " + courseDuration + " years");
        System.out.println("Research Topic: " + researchTopic);
    }

    // toString method
    @Override
    public String toString() 
    {
        return super.toString() + ", Research Topic: " + researchTopic;
    }
}

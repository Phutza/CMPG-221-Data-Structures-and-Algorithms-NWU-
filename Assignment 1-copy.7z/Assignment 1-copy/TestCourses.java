
/**
 * Write a description of class t here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestCourses 
{
    public static void main(String[] args) 
    {
        Course undergradCourse = new UndergraduateCourse("Computer Science and information systems", 3, true);
        Course PostGradCourse = new PostGraduateCourse("Software development", 1, "Advanced Data Structures");

        // Displaying the details
        undergradCourse.displayCourseDetails();
        PostGradCourse.displayCourseDetails();

        // Showing the use of the toString method
        System.out.println(undergradCourse.toString());  
        System.out.println(PostGradCourse); 
    }
}

/**
 * Write a description of class w here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
abstract class Course 
{
    protected String courseName;
    protected int courseDuration;

    // Constructor
    public Course(String courseName, int courseDuration) 
    {
        this.courseName = courseName;
        this.courseDuration = courseDuration;
    }

    // Accessors
    public String getCourseName() 
    {
        return courseName;
    }

    public int getCourseDuration() 
    {
        return courseDuration;
    }

    // Mutators
    public void setCourseName(String courseName) 
    {
        this.courseName = courseName;
    }

    public void setCourseDuration(int courseDuration) 
    {
        this.courseDuration = courseDuration;
    }

    // Abstract method
    public abstract void displayCourseDetails();

    // toString method
    @Override
    public String toString() 
    {
        return "Course Name: " + courseName + ", Course Duration: " + courseDuration + " years";
    }
}